---
layout: default
vendor: cis
subject: ai-agent
module: navigating the partner portal
title: Building an Autonomous AI Agent
author: jed demeule
type: lab guide

---

<!-- markdownlint-disable MD033 MD045 MD024 MD034 MD001 MD046 MD025-->

---

- [📋 Required Resources](#-required-resources)
- [Task 1: Managing Knowledge Bases](#task-1-managing-knowledge-bases)
- [Task 2: Configure an Autonomous AI Agent in Webex Connect](#task-2-configure-an-autonomous-ai-agent-in-webex-connect)
- [Task 3: Connect to the Previously Configured Knowledge Base](#task-3-connect-to-the-previously-configured-knowledge-base)

---

### Objective

In this lab series, you will gain practical experience with configuring and deploying an Autonomous AI Agent using Webex Connect and Webex AI Agent Studio. Step by step, you'll build a functional agent, connect it to a knowledge base

At the end of this lab, you'll have a working AI agent capable of responding to users for the voice channel, leveraging structured knowledge, and fulfilling actions through backend integration.

After completing this activity, you will be able to meet this objective:

- Design, configure, and test an Autonomous AI Agent using Webex Connect and Webex AI Agent Studio.
- Define AI Agent behavior.
- Connect your AI Agent to a knowledge base.

## 📋 Required Resources

### Navigation URLs and Logins

| 🖥️ Server       | 🔗 URL                                               | 👤 User ID             | 🔒 Password           |
|-----------------|------------------------------------------------------|------------------------|-----------------------|
| Webex CC Admin Account | <a href="https://admin.webex.com" target="_blank">https://admin.webex.com</a> | aiagentXX@sliwxcc.com | C!sco123 or C!sco133 (pod 12)  |
| Webex CC Desktop| <a href="https://desktop.wxcc-us1.cisco.com" target="_blank">https://desktop.wxcc-us1.cisco.com</a> | aiagentXX@sliwxcc.com  aisupervisorXX@sliwxcc.com  | C!sco123 |
| Webex Connect| Cross launch through the Control Hub                    | None required          | None required         |
| Webex Engage | Cross launch through the Control Hub                    | None required          | None required         |
| Analyzer     | Cross launch through the Control Hub                    | None required          | None required         |

`PIN is changed weekly and will be provided by your instructor`

### Individual Persona Webex Login Information

| 🧾 Account Type                  | 👤 Account Name                                | 🔒 Password |
|----------------------------------|------------------------------------------------|-------------|
| Administrator Account            | aiagentXX@sliwxcc.com                          | C!sco123    |
| Webex/CC Administrator Account   | aiagentXX@sliwxcc.com                          | C!sco123    |
| CC Agent Account                 | aiagentXX@sliwxcc.com                          | C!sco123    |
| CC Supervisor Account            | aisupervisorXX@sliwxcc.com                     | C!sco123    |

`PIN is changed weekly and will be provided by your instructor`

### Pre Existing Configuration Objectss

| ⚙️ Configuration Item        | 📝 Description             |
|------------------------------|----------------------------|
| Site                         | AI XX                      |
| Team                         | AI XX                      |
| User Profile for Agent       | Administrator Profile      |
| User Profile for Supervisor  | Premium Agent User Profile |
| Desktop Profile              | Agent-Profile 99           |
| Skill Definition             | AI XX (Boolean)            |
| Skill Profile                | AI XX                      |
| Multimedia Profile           | Multimedia_Profile_99      |

`XX is your assigned 2 digit pod number`

### Configuration Objects and Naming Convention—Contact Center Extensions

| Role                 | Extension  |
|----------------------|------------|
| Agent Extension      | 70XX       |
| Supervisor Extension | 71XX       |

`XX is your assigned 2 digit pod number`  

---

## Task 1: Managing Knowledge Bases

T1-1\. Log in to the <a href="https://admin.webex.com" target="_blank">https://admin.webex.com</a> interface.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-m2-kb-image1.png" width="100%">  

T1-2\. On the Contact Center main page, locate the **Quick Links** section on the right-hand side and open the hyperlink to **Webex AI agent** studio to view the AI Agent Studio.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-m2-kb-image2.png" width="100%">  

T1-3\. Select the Knowledge Base option on the left side of the AI Agent Studio and click the **Create Knowledge Base** button.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-m2-kb-image3.png" width="100%">

T1-4\. Enter the following values for the new knowledge base:

- Knowledge base name: `StudentXX_KB`
- Description: `My Knowledge Base`

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-m2-kb-image4.png" width="100%">  

T1-5\. Observe that there are three tabs:

- Files: `This is where you can upload your documents`
- Documents: `This is where you can create documents and organize them into categories`
- Information: `This is where you can see the history of changes to the knowledge base`

On the default **Files** tab press the *Add Files* button.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-m2-kb-image5.png" width="100%">

T1-6\. Locate the following files (review the content if desired) and select them to add to the SurfboardXX Knowledge Base:

- Information on surfboards and their history: `surfboards.txt`
- Information on swimwear and its history: `swimsuits.txt`
- Information on Sharks: `sharks.txt`

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-m2-kb-image6.png" width="100%">

T1-7\. After adding the files, click the **Process Files** button to make them usable by the AI.

>Note: The size and complexity of the files will impact how long it takes to process them

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-m2-kb-image7.png" width="100%">

T1-8\. Confirm that the files are processed correctly.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-m2-kb-image8.png" width="100%">

T1-9\. Click the back arrow in the webpage to return to the knowledge base, select the **Documents** tab, and click the **Create Document** button.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-m2-kb-image8.5.png" width="100%">

T1-10\. Set the following values for the new document:

- Name: `Locations`
- Select Existing Category: `Unassigned` (default)

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-m2-kb-image9.png" width="100%">

T1-11\. Copy the text below (or from the **locations.txt** file) and paste it into the document creation page, then click the **Save** button when finished.

```text
### Super Surf Shack – Pipeline
- **Address:** 59-123 Kamehameha Hwy, Haleiwa, HI 96712, USA  
- **Phone:** +1 808-555-PIPE  
- **Nearest Beach:** Banzai Pipeline, Oahu  
- **Hours:** Mon–Sun: 7:00 AM – 6:00 PM  

---

### Super Surf Shack – Gold Coast
- **Address:** 120 Surfer's Paradise Blvd, Surfers Paradise QLD 4217, Australia  
- **Phone:** +61 7 5555 1234  
- **Nearest Beach:** Snapper Rocks, Gold Coast  
- **Hours:** Mon–Sat: 8:00 AM – 5:30 PM; Sun: 9:00 AM – 4:00 PM  

---

### Super Surf Shack – Jeffreys Bay
- **Address:** 89 Da Gama Rd, Jeffreys Bay 6330, South Africa  
- **Phone:** +27 42 555 4321  
- **Nearest Beach:** Supertubes, Jeffreys Bay  
- **Hours:** Mon–Fri: 7:30 AM – 6:00 PM; Sat–Sun: 8:00 AM – 5:00 PM  

---

### Super Surf Shack – Uluwatu
- **Address:** Jl. Labuan Sait, Pecatu, Bali 80361, Indonesia  
- **Phone:** +62 361 555 9876  
- **Nearest Beach:** Uluwatu Beach, Bali  
- **Hours:** Daily: 6:30 AM – 7:00 PM  

---

### Super Surf Shack – Teahupo’o
- **Address:** PK 0.5 Teahupo’o, Tahiti, French Polynesia  
- **Phone:** +689 40 555 777  
- **Nearest Beach:** Teahupo’o Reef Break  
- **Hours:** Mon–Fri: 8:00 AM – 6:00 PM; Sat: 9:00 AM – 3:00 PM; Closed Sun
```

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-m2-kb-image10.png" width="100%">

T1-12\. Select the **Information** tab and observe that this knowledge base is not currently assigned to any Autonomous AI Agent. You will also see the history of changes to the knowledge base.

---

## Task 2: Configure an Autonomous AI Agent in Webex Connect

In this task you will configure a new Autonomous Agent in Webex Connect.

#### Activity Procedure

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image00.png" width="100%">

T2-1\. After logging into the Webex Connect platform, click on **App Tray**, select **AI Agent Studio**, and then click the **+ Create agent** button in the upper right-hand corner.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image01.png" width="25%">

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image02.png" width="100%">

T2-2\. Select **Start from scratch** and click **Next**.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image03.png" width="100%">

T2-3\. On the **Create an AI Agent** page, select the **Autonomous** option and configure the following settings:

- Agent Name: `StudentXX_Autonomous_AI_Agent` (XX is your student number)
- System ID: accept default
- AI engine: `Webex AI Pro 1.0`
- Agent’s goal:

```text
You are a helpful, friendly and professional AI Assistant for the Order Management department of the ACME company. Your primary responsibilities include answering customer inquires about ACME products accurately and clearly, responding to general FAQs in a concise and informative manner and assisting customers with managing their orders.
```

The **Agent’s goal** section defines the overall purpose and role of the AI Agent—what it is designed to achieve and how it should assist users.

Feel free to experiment with different wording for the Agent’s goal. You can click on the tooltip link for guidance from the AI product team (this is also where you’ll find the AI Agent product documentation). While we will provide the exact prompts used in our setup, these are not the only valid approaches. There is no single "correct" way to structure a prompt - variations can lead to different outcomes. We encourage you to explore and refine your prompts to see what works best for your use case.

You can refine and iterate on the original prompts to demonstrate how adjusting the wording can correct undesired behavior.

Click the **Create** button in the bottom right corner to continue.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image04.png" width="100%">

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image05.png" width="100%">

T2-4\. On the **AI Agent Profile** tab, verify that the **Agent’s goal** field is populated, then customize the **Welcome message** as shown in the example below:

```text
Hello, I´m Daniel, your customer service representative at ACME Order Management department. How can I help you today?
```

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image06.png" width="100%">

T2-5\. Continue to the Instructions section. Provide detailed, step-by-step guidance on how the agent should execute its tasks, including specific actions, response formatting, and behavior rules to ensure accurate and efficient interactions.

You can click Insert Example to view a basic, generic template or refer to the tooltip link for additional guidance (we will actually stick to the template proposed in the guidelines for writing instructions). When working with LLM-powered agents, providing clear and actionable instructions is essential to ensure they perform tasks accurately and efficiently.

To achieve this, it’s important to first identify the specific actions the agent needs to fulfill so they can be explicitly referenced in this section. Based on our goal list, we will define actions for the following capabilities:

- Check order delivery status – Action: `[fetch_status]`
- Change the delivery date – Action: `[change_date]`
- Add/Edit a "Safe Area" for delivery – Action: `[safe_area]`
- Cancel an order, with escalation prompts from the AI Agent – Action: `[cancel_order]`

Our approach will be to provide instructions in a structured format, clearly outlining the **Identity** we want for our Agent, the **Context** the Agent will work on, the **Tasks** the Agent will carry on including the actions it needs to fulfill and the restrictions that it may apply, and, finally, any response guidelines we want it to follow. To make the actions explicit, we will enclose them in square brackets, like this: **[fetch_status]**.

This is our proposed prompt for the instructions:

```text
## 1. Identity

You're Daniel, an expert customer service representative who works for ACME´s Order Management department and assists ACME´s customers in a helpful, friendly and professional manner on any queries related to ACME´s products and orders.

## 2. Context

The conversation with the customer can be about product information and/or specific details on an existing order. In the case it is related to an order, the customer may want to modify certain details of the order or even cancel it.

The conversation may happen on different channels (voice, email, SMS...). Your responses should be appropriate to the channel in use in regards to the tone, clarity and structure.

## 3. Task

You have two main tasks:

TASK 1: You will accurately answer any customer query in relation to the ACME products in a friendly and professional manner. Refer to the knowledge sources as appropriate (such as product documentation, FAQ´s, support articles...) to ensure information is correct and consistent.

TASK 2: You will provide proactive information to the customer in relation to their order status and shipment details. Before providing any information, you will collect the order Id number ("orderId") to be able to determine what order is being referenced. If the orderId is not available, you will ask the customer for it. Once the orderId is known, you can perform any of the following actions:

1. [fetch_status] - use the "orderId" to fetch the status of the order and inform the customer.

2. [change_date] - change the desired delivery date. A [change_date] action will always be followed by a [fetch_status].

3. [safe_area] - add or update the specified safe area for the courier to leave the package.

4. [cancel_order] - cancels the current order by changing the value of "deliveryStatus" to "Cancelled".

The start of the conversation with the customer will follow the below structure:

After delivering the Welcome message to the customer, you will fetch the status of the order and send the status information to the customer, following the given response guidelines. The status information message will depend upon the "deliveryStatus", as follows:

- If the status is "placed", thanks the customer for his purchase of a "productName" and inform that we´ll follow up with him once it is ready to be shipped.

- If the status is "cancelled", inform the customer that the order is cancelled. Include the "orderId" and the "producName". Also offer to contact us on <WxCC INBOUND NUMBER>.in case of any query about the operation.

- in any other status case (shipped or ready-to-ship), the message will inform about the status and will contain the "orderId", the "productName" , the "deliveryStatus", the "deliveryETA" and the "deliveryAddress" in a bulleted format. Also offer the customer to make any changes to the order.

The customer may ask to refresh the status information. If so, fetch the status again.

If the customers asks to cancel the order, always execute the [cancel_order] action.

After changing any of the order details, provide the customer an update on the order information.

Following restrictions will apply:

- if an order is cancelled, the user can not make any modification to the order, the only way the user can proceed is by contacting a human expert on the number <WxCC INBOUND NUMBER>..

-If the user requests for order status update, provide the order status including the "deliveryAddress", "deliveryStatus" and "deliveryETA" in bulleted list format. When you respond to this message always greet the user in a polite way and include the "firstName" in the greeting along with the "orderId".

## 4. Response Guidelines

- you will always respond greeting the customer in a formal way including their name.

- If the response is via email, include a polite closing signature including your name, the company name and the department.

- when the response includes order information details, try to provide them in a bulleted list.

- Transfer to an Agent is only possible in a voice conversation.

- You will answer questions strictly within the scope of this order management instructions. Do not provide responses, opinions, or suggestions that are unrelated to this scope, even if prompted. If a question falls outside the designated topic, politely respond with: 'I am only able to assist with order management at this time.' Avoid making assumptions or speculating beyond the provided information.
```

**NOTE**: The **\<WxCC INBOUND NUMBER\>** is the DN you have assigned for inbound calls to your Webex CC flow.

**Instructions** serve as a guide for the full range of the AI Agent’s capabilities and also provide a space to refine responses retrieved from the Knowledge Base. The proposed prompt is the result of few iterations. You can experience your prompt design starting with a simpler prompt like:

```text
Answer any questions from the user in a friendly and professional manner, referring to the relevant Knowledge sources as appropriate.

You will also be able to manage any existing orders as follows: Collect an Order ID Number ("orderId") to be able to determine what order is being referenced.

These are your available actions, once the "orderId" is known:

1. [fetch_status] - use the "orderId" to fetch the status of the order.
2. [change_date] - change the desired delivery date.
3. [safe_area] - add or update the specified safe area for the courier to leave the package.
4. [cancel_order] - cancels the current order by changing the value of "deliveryStatus" to "Cancelled".

If an order cannot be canceled because it has already shipped, the only way the user can proceed is by contacting a human expert on the number <WxCC INBOUND NUMBER>. This is facilitated in the [cancel_order] action.
```

**TIP**: You can also prompt another LLM (like ChatGPT) to generate the prompt for your Agent.

Fill in the **Instructions** field with the proposed content (longer or shorter as you prefer; you may copy the instructions from here and paste them into your AI Agent), then click the **Save changes** button.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image07.png" width="100%">

T2-6\. Complete and save the initial setup for your Autonomous AI Agent. Note that preview is not yet available; this AI Agent requires a Knowledge Base or configured Actions to function.

Reflect on the prompt (instructions) we have designed for our Agent. Note that in our design, we have taken these **TIPS** in mind:

- **Keeping It Simple**: Use clear, concise language. Avoid technical jargon or overly complex sentences.
- **Using Markdown**: Use headings and ordered/unordered list markdown for best results.
- **Stating the AI Agent's Identity**: Begin by clearly defining the agent’s persona (e.g., “You are a helpful customer support agent…”).
- **Breaking It Down**: Outline tasks step by step. For instance, “First, confirm your account number. Then, describe your issue.”
- **Planning for Errors**: Include fallback phrases such as, “I’m sorry, could you please repeat that?” if the input isn’t clear.
- **Preserving Context**: Remind the agent to remember previous responses to ensure continuity in long conversations.
- **Referencing Actions**: Clearly instruct how to use external actions at different steps.
- **Adding Guardrails**: Instruct the AI Agent to respond only in the context of the goal.
- **Adding Examples**: To improve accuracy add examples wherever needed.

### Activity Verification

You have successfully completed this activity when you have attained this result:

- You have created your Autonomous AI Agent and provided its initial settings.

---

## Task 3: Connect to the Previously Configured Knowledge Base

In this task you will connect your Autonomous AI Agent to its Database, train it and observe your results.

### Activity Procedure

T3-1\. On your StudentXX Autonomous AI Agent configuration page, click the **Knowledge** tab:

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image08.png" width="100%">

T3-2\. Select **StudentXX_KB** from the Knowledge Base drop-down list and click **Save changes**.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image09.png" width="100%">

T3-3\. Confirm that your Autonomous AI Agent is ready to be published, then click the **Publish** button and verify that the status changes to **Published**.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image10.png" width="100%">

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image12.png" width="100%">

T3-4\. Click the **Preview** button at the top right of the page. The preview panel will open and you should see your AI Agent **Welcome** message.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image13.png" width="35%">

T3-5\. Ask your AI Agent a few questions in a natural, conversational way. Use everyday language to see how the agent understands and responds:

- **What do you know about shark repellents?**
- **Do you offer surfboards?**
- **I need a swimsuit. Can you offer one to me?**
- **Thank you. Goodbye!**

Observe the responses—they should be similar to the examples shown below.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image14.png" width="35%">

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image15.png" width="35%">

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image16.png" width="35%">

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image17.png" width="35%">

T3-6\. Minimize the **Preview** panel and click the **Language** tab.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image18.png" width="100%">

T3-7\. Set the language and voice settings for text-to-speech (TTS) used in voice calls. From the **Select voice** drop-down list, choose **en-us-Daniel** (or any other preferred voice), then click **Save changes**.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image19.png" width="50%">

T3-8\. Click **Publish** to apply the changes to your AI Agent. If you skip this step, the agent will continue to use the previous configuration.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image20.png" width="100%">

T3-9\. Create a new Flow for voice calls to test your Autonomous AI Agent. In **Webex Control Hub**, navigate to **Services → Contact Center → Flows**, then open the **Manage Flows** drop-down and select **Create Flows**.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image21.png" width="100%">

T3-10\. In the **Flow Designer** (which opens in a new tab), select **Create a new Flow** and choose **Start Fresh** to begin with a blank flow.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image22.png" width="80%">

T3-11\. Enter the following name for your flow: **StudentXX_Autonomous_AI_Agent_Flow** and click **Create Flow**. (XX is your student number)

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image24.png" width="100%">

T3-12\. Add a **Virtual Agent V2** activity to the right of the **Start Flow** activity and connect the **output port** of **Start Flow** to the new activity.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image25.png" width="100%">

T3-13\. Configure the properties of the **Virtual Agent V2** activity as follows:

- Activity Label: `Autonomous_AI_Agent`
- Activity Description: `It triggers Autonomous AI Agent`
- Conversational Experience: `Static Contact Center AI Config`
- Contact Center AI Config: `Webex AI Agent (Autonomous)`
- Virtual Agent: `StudentXX_Autonomous_AI_Agent` (XX is your student number)

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image26.png" width="35%">

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image27.png" width="35%">

T3-14\. Add a **Queue Contact** activity to the right of the **Virtual Agent V2** activity and connect the **Escalated** **output port** of **Virtual Agent V2** to the new activity.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image28.png" width="80%">

T3-15\. Configure the properties of the new **Queue Contact** node as follows (XX is your student number):

- Activity Label: `AI XX`
- Activity Description: `Queue the call and select the Agent`
- Contact Handling: `Static Queue`
- Queue: `AI XX`

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image29.png" width="35%">

T3-16\. Add a **Play Music** activity to the right of the **Queue Contact** activity. Connect the **successful** output port of **Queue Contact** to the new activity, then connect the **successful** output port of **Play Music** back to its own **Inbound** port to create a loop for the music-on-hold (MOH) prompt.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image30.png" width="100%">

T3-17\. Configure the new **Play Music** activity with the following settings:

- Acrtvity Label: `MOH`
- Activity Description: `It plays music while waiting for an Agent.`
- Contact Handling: `Static Queue`
- Music Settings: `Static Audio File`
- Music File: `CheezyHoldmusic.wav`

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image31.png" width="35%">

T3-18\. Add a **Disconnect Contact** activity above your **QueueXX** (Queue Contact) activity and connect the **Handled** output port of the **Virtual Agent V2** activity to the **Disconnect Contact**.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image32.png" width="100%">

T3-19\. Add a **Play Message** activity below the MOH loop and connect the **Error** output ports of all other activities to this **Play Message** activity.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image33.png" width="100%">

T3-20\. Configure the new **Play Music** activity with the following settings:

- Activity Label: `Error_Message`
- Activity Description: `It plays an Error Message.`
- Prompt: `Enable Text-to-Speech`
- Connector: `Cisco Cloud Text-to-Speech`
- Text-to-Speech Message: `I am sorry, an error occurred. Please call us later. Goodbye!`

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image35.png" width="35%">

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image36.png" width="35%">

T3-21\. Add another **Disconnect Contact** activity to the right of the **Error_Message** activity. Connect both the **successful** and Undefined Error output ports of the **Error Message** activity to the new activity. Finally, **Validate** and **Publish** your flow.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image37.png" width="100%">

T3-22\. Go back to **Control Hub**, navigate to **Channels → Student99_AI_Agent_EP**, and update the **Routing Flow** field by selecting your newly created flow:

- **StudentXX_Autonomous_AI_Agent_Flow.**

Click **Save** to apply the changes.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-4-image38.png" width="100%">

T3-23\. Call your Webex CC lab DN and interact with your **Autonomous AI Agent**. Ask questions based on the contents of your Knowledge Base, for example:

- **Tell me please about the types of the swimsuits.**
- **What are shark defensive tools?**
- **What are materials and construction for the surfboards?**

T3-24\. Listen to the AI Agent’s responses and verify that they match the information provided in your Knowledge Base files.

Finally, say: **“Connect me to a human agent”**. Confirm that your call is transferred to a live agent (if available), or you hear music on hold (MOH).

#### Activity Verification

You have successfully completed this activity when you have attained this result:

- You connected your Autonomous AI Agent to your existing Knowledge Base
- You can test your Autonomous AI Agent in the Preview window
- Your Autonomous AI Agent provides relevant information when you call the Webex CC DN
- Your Autonomous AI Agent can transfer calls to a human agent.
