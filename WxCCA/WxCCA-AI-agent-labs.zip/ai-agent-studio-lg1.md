---
layout: default
vendor: cis
subject: ai-agent
module: AI Agent Studio
title: AI Agent Studio
author: jed demeule
type: lab guide

---

<!-- markdownlint-disable MD033 MD045 MD024 MD034 MD001 MD046 MD025-->

---

### Navigation

- [📋 Required Resources](#-required-resources)
- [📙 Accessing and Navigating the AI Agent Interface](#-accessing-and-navigating-the-ai-agent-interface)

---

## 📋 Required Resources

### Navigation URLs and Logins

| 🖥️ Server       | 🔗 URL                                               | 👤 User ID             | 🔒 Password           |
|-----------------|------------------------------------------------------|------------------------|-----------------------|
| Webex CC Admin Account | <a href="https://admin.webex.com" target="_blank">https://admin.webex.com</a> | aiagentXX@sliwxcc.com | C!sco123 or C!sco133 (pod 12)  |
| Webex CC Desktop| <a href="https://desktop.wxcc-us1.cisco.com" target="_blank">https://desktop.wxcc-us1.cisco.com</a> | aiagentXX@sliwxcc.com  aisupervisorXX@sliwxcc.com  | C!sco123 |
| Webex Connect| Cross launch through the Control Hub                    | None required          | None required         |
| Webex Engage | Cross launch through the Control Hub                    | None required          | None required         |
| Analyzer     | Cross launch through the Control Hub                    | None required          | None required         |

`PIN is changed weekly and will be provided by your instructor`

### Individual Persona Webex Login Information

| 🧾 Account Type                  | 👤 Account Name                                | 🔒 Password |
|----------------------------------|------------------------------------------------|-------------|
| Administrator Account            | aiagentXX@sliwxcc.com                          | C!sco123    |
| Webex/CC Administrator Account   | aiagentXX@sliwxcc.com                          | C!sco123    |
| CC Agent Account                 | aiagentXX@sliwxcc.com                          | C!sco123    |
| CC Supervisor Account            | aisupervisorXX@sliwxcc.com                     | C!sco123    |

`PIN is changed weekly and will be provided by your instructor`

### Pre Existing Configuration Objectss

| ⚙️ Configuration Item        | 📝 Description             |
|------------------------------|----------------------------|
| Site                         | AI XX                      |
| Team                         | AI XX                      |
| User Profile for Agent       | Administrator Profile      |
| User Profile for Supervisor  | Premium Agent User Profile |
| Desktop Profile              | Agent-Profile 99           |
| Skill Definition             | AI XX (Boolean)            |
| Skill Profile                | AI XX                      |
| Multimedia Profile           | Multimedia_Profile_99      |

`XX is your assigned 2 digit pod number`

### Configuration Objects and Naming Convention—Contact Center Extensions

| Role                 | Extension  |
|----------------------|------------|
| Agent Extension      | 70XX       |
| Supervisor Extension | 71XX       |

`XX is your assigned 2 digit pod number`  

### Activity Objective

Upon completion of this training, participants will be able to navigate the Webex AI Agent Studio interface, understand the different AI agent types, configure key settings for both autonomous and scripted agents, utilize testing and monitoring tools, and understand how agents integrate with channels and impact reporting.

## 📙 Accessing and Navigating the AI Agent Interface

### Access AI Agent Studio thru the Control Hub

1\. Access the <a href="https://admin.webex.com" target="_blank">https://admin.webex.com</a> interface and login.

2\. Click on the **Services** --> **Contact Center** option and notice on the left hand side you have a link to **Customer Experience**--> **AI Agents**. This link opens a page that has links to the AI Agent Studio and also the AI Agent help website.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-m3-image1.png" width="100%">  

3\. Back On the contact center main page on the right hand side under **Quick Links** is a hyperlink that goes to **Webex AI agent** studio.  Open this link up and you will see the AI Agent Studio

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-m3-image2.png" width="100%">  

4\. Notice in this interface on the left-hand side, you have three objects the top object is the Dashboard which is highlighted, this  shows you all your currently configured AI agents and whether they are Scripted or Autonomous.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-m3-image3.png" width="100%">

5\. Select the second object called Knowledge .  Below that is what looks like a piece of paper with writing on it that icon is for the knowledge basis that you can configure. And finally, the last object is a link to the help for AI Agent.  

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-m3-image4.png" width="100%">  

6\. Finally select the last object it will open up a link in a new tab to the help for AI Agent. (If you don't see it make sure pop-ups are allowed for the Control Hub website)

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-m3-image5.png" width="100%">

7\. Select the **Preview** button on the **Appointment Booking** Scripted AI Agent, a chat window will open up. Interact with the AI Agent using the below:

- Book an appointment
- Enter a date in the future
- Enter a time of day for the appointment
- Enter a fake Dr. Name (Example Dr. Smith)
- Confirm the date and time when asked
- Enter your name (or a fake name)
- Enter your birthdate (or a fake one)
- Enter 6 random digits
- Enter a 10 digit phone number

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-m3-image6.png" width="100%">

8\. Click on the Appointment Booking card on the dashboard and open up the Scripted AI Agent configuration interface.  

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-m3-image7.png" width="100%">

> Note: this interface will be covered in detail in the Scripted AI Agent section

9\. In the upper right hand corner there's a circle with three dots in it select that and notice that you can do the following:

- `Copy the agent ID:` Copies the name of the AI Agent
- `Copy the access token:` Copies the token used to invoke this thru the API
- `Delete the AI agent:` Deleted the AI Agent
- `Export AI agent:` Export to a portable json file

> Note: the 3 dots is also available on the card on the dashboard

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-m3-image8.png" width="100%">

10\. Back on the dashboard notice in the upper right hand corner there's the ability to import an AI Agent that was previously exported as well as the ability to create a new AI Agent. Press the **+ Create Agent**.  Notice you can pick from a template or **Start from scratch**.  At this point press the **Cancel** button as you will create AI Agents in future sections.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-m3-image9.png" width="100%">

11\. Let's test an autonomous agent next, Select the **Surfboards99** and then press the preview button. Notice you have the option to test a voice call or a digital interaction. Select **Start a call**

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-m3-image10.png" width="100%">

12\. You should be greeted by the AI Agent, you can test out the agent by asking questions like the following:

- Tell me the history of surfboards and Hawaii
- What are surfboards made of
- What is a longboard and what other type of boards are there

13\.  Try it with Chat at well.

### Access AI Agent Studio thru the Webex Connect

14\. Access the <a href="https://sunsetgoldtenant.us.webexconnect.io" target="_blank">https://sunsetgoldtenant.us.webexconnect.io</a> interface and login.

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-m3-image11.png" width="100%">

15\. Open up the App Tray and select the AI Agent. This is an alternate way to reach the AI Agent Studio

<img src="https://d31uennr5dcgcs.cloudfront.net/cisco-training/ai-agent/cis-ai-agent-lg-m3-image12.png" width="100%">  

### End of Lab
